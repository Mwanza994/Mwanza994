<?php if (!defined('ABSPATH')) exit; ?><!doctype html>
<html <?php language_attributes(); ?>><head><meta charset="<?php bloginfo('charset'); ?>"><meta name="viewport" content="width=device-width,initial-scale=1"><?php wp_head(); ?></head><body <?php body_class(); ?>><?php wp_body_open(); ?>
<a class="skip-link" href="#main">Skip to content</a>
<header class="site-header"><?php if(!mbili_template('header')): ?><div class="header-inner"><a class="wordmark" href="<?php echo esc_url(home_url('/')); ?>" aria-label="Mbili Mwanza home">Mbili Mwanza</a>
<button class="menu-toggle" aria-expanded="false" aria-controls="primary-menu">Menu <span aria-hidden="true">＋</span></button>
<nav id="primary-menu" aria-label="Primary"><?php wp_nav_menu(['theme_location'=>'primary','container'=>false,'fallback_cb'=>'mbili_fallback_menu','depth'=>1]); ?></nav></div><?php endif; ?></header>
<main id="main">
