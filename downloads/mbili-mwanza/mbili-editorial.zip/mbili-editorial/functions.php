<?php
if (!defined('ABSPATH')) exit;
add_action('after_setup_theme', function () {
    load_theme_textdomain('mbili-editorial', get_template_directory() . '/languages');
    add_theme_support('title-tag'); add_theme_support('post-thumbnails');
    add_theme_support('responsive-embeds'); add_theme_support('automatic-feed-links');
    add_theme_support('html5', ['search-form','comment-form','comment-list','gallery','caption','style','script']);
    add_theme_support('align-wide'); add_theme_support('custom-logo');
    register_nav_menus(['primary'=>'Primary navigation','footer'=>'Footer navigation']);
    add_image_size('mbili-card', 1000, 750, true);
    add_image_size('mbili-hero', 1800, 1200, false);
});
add_action('wp_enqueue_scripts', function () {
    wp_enqueue_style('mbili-editorial', get_template_directory_uri().'/assets/editorial.css', [], '1.0.0');
    wp_enqueue_script('mbili-editorial', get_template_directory_uri().'/assets/editorial.js', [], '1.0.0', ['strategy'=>'defer','in_footer'=>true]);
});
function mbili_template($slot) {
    $id = absint(get_option('mbili_template_'.$slot));
    if (!$id || !did_action('elementor/loaded') || get_post_status($id)!=='publish') return false;
    if (get_post_meta($id,'_elementor_edit_mode',true)!=='builder') return false;
    $html = \Elementor\Plugin::instance()->frontend->get_builder_content_for_display($id, true);
    if (!$html) return false;
    echo $html; // Elementor renders and escapes its saved widget data.
    return true;
}
function mbili_fallback_menu() {
    echo '<ul class="menu">';
    foreach (['work'=>'Work','about'=>'About','writing'=>'Writing','resources'=>'Resources','contact'=>'Contact'] as $path=>$label) {
        echo '<li><a href="'.esc_url(home_url('/'.$path.'/')).'">'.esc_html($label).'</a></li>';
    }
    echo '</ul>';
}
add_action('customize_register',function($c){
    $c->add_section('mbili_brand',['title'=>'Mbili identity & social links','priority'=>30]);
    foreach(['accent'=>'Accent color','linkedin'=>'LinkedIn URL','instagram'=>'Instagram URL','contact_email'=>'Inquiry recipient email'] as $key=>$label){
        $c->add_setting('mbili_'.$key,['default'=>$key==='accent'?'#b54b2d':'','sanitize_callback'=>$key==='accent'?'sanitize_hex_color':($key==='contact_email'?'sanitize_email':'esc_url_raw')]);
        $c->add_control('mbili_'.$key,['label'=>$label,'section'=>'mbili_brand','type'=>$key==='accent'?'color':($key==='contact_email'?'email':'url')]);
    }
});
add_action('wp_head',function(){ $color=get_theme_mod('mbili_accent','#b54b2d'); if(sanitize_hex_color($color)) echo '<style>:root{--accent:'.esc_html($color).'}</style>';},20);

add_action('elementor/theme/register_locations',function($locations){$locations->register_all_core_location();});

add_action('elementor/frontend/widget/before_render',function($widget){
    $classes=(string)$widget->get_settings('_css_classes');
    if(str_contains($classes,'hero-photo') && !\Elementor\Plugin::instance()->editor->is_edit_mode())$widget->add_render_attribute('_wrapper','data-parallax','true');
});
