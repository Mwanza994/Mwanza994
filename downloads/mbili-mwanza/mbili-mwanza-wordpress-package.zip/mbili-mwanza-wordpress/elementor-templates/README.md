# Elementor template sources

The supported installation path is Tools → Mbili setup after activating the companion plugin and theme. It resolves portable URL tokens, imports the documents, and connects the shared template slots.

These individual Elementor JSON files are also supplied for source review or selective manual import. Before manual import, replace `__MM_HOME__` with the target origin (no trailing slash) and `__MM_PORTRAIT__` with the desired image URL. Then import through Templates → Saved Templates. The theme-slot option IDs must be assigned to your imported template IDs if bypassing the setup tool; manual imports alone do not configure routing.

The documents contain real Elementor containers and native widgets plus the companion plugin's small dynamic widgets. They do not require Elementor Pro. Static image placeholders must be replaced with your authentic images.
