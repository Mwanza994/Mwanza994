# QA report — 10 November 2026

## Tested environment

Isolated local WordPress 6.8.3 with Elementor Free 3.33.0, PHP 8.1 WebAssembly, SQLite integration, and Chromium/Playwright. The compiled Elementor release was downloaded from its official GitHub release and its SHA-256 checked. Production should use supported stable versions and repeat these checks on the actual host. This is a local build, not a deployed or inspected production installation.

## Completed checks

| Check | Result |
|---|---|
| PHP 8.1 syntax | Passed, all 19 PHP files |
| Frontend/admin JavaScript syntax | Passed |
| Theme and plugin activation | Passed in isolated WordPress |
| Starter setup | Passed; pages, shared templates, global styles, and six draft case studies created |
| Re-running imports | Passed; existing matching documents preserved without duplication |
| Page routes | Home, About, Work, case study, Writing, article, Resources, resource, Contact returned 200; missing page returned 404 |
| H1 hierarchy | One H1 on tested page types |
| Responsive home | 320, 390, 768, 1024, and 1440px; no horizontal overflow; portrait placeholder loaded |
| Mobile navigation | Toggle opens, Escape closes, focus returns to toggle |
| Browser errors | No page JavaScript errors in responsive run |
| Native Elementor architecture | 79 containers, 78 Heading widgets, 35 Text Editor widgets, 15 Button widgets, 2 Image widgets; no HTML widgets |
| Elementor design editing | Editor panel and live preview frame opened for the imported Home document |
| Publishing interface | Structured project fields and visual-story repeater loaded in WordPress |
| Repeater controls | Add, move, and remove rows passed; submitted field names remained unique |
| Dynamic featured work | Published featured test case appeared in the homepage query |
| Case-study rendering | Overview/problem/solution data and interleaved story text rendered |
| Optional case-study sections | Empty results section hidden |
| Input handling | Rich-text script tags stripped; KPI data limited to four cards |
| Elementor deactivated | Case-study summary and solution remained readable through the native fallback |
| Inquiry security | Invalid nonce rejected; missing email rejected; honeypot rejected |
| Inquiry success path | Passed through a **test-only intercepted mail transport**; no real email sent |
| Inquiry rate limit | First five valid attempts accepted, sixth limited |
| Resource content | Resource template routed and rendered the test description, destination, and disclosure |
| Delivery archives | ZIP integrity and file manifest checked at packaging |

All “QA” posts/resources, temporary admin bypasses, mail interception, test dependencies, and test WordPress data exist only in the isolated harness. They are excluded from the delivery ZIPs. Starter content contains no fabricated article, KPI, testimonial, or project outcome.

## Required on the deployment host

- Verify SMTP/mailbox delivery, spam-folder behavior, and recipient configuration. Local mail handoff tests are not an inbox-delivery guarantee.
- Replace the two portrait placeholders with real optimized images; complete case-study evidence and appropriate alternative text.
- Review privacy copy, set the direct privacy contact, providers, retention, legal requirements, and policy selection. The supplied legal text is a draft.
- Validate actual Elementor licenses/plugins if adding Pro or changing the stack. The supplied implementation requires no Pro license.
- Test with the final plugin stack, host caching, production URLs, SSL, redirects, and sitemap indexing.
- Confirm filters and pagination with the real volume/categories of published content; the isolated dataset tested route/render/query behavior, not a production-scale catalog.
- Measure LCP, CLS, and INP using the actual host, real images, and representative devices. No production Core Web Vitals score is claimed. Targets remain LCP ≤2.5s, CLS ≤0.1, and INP ≤200ms.
- Complete manual screen-reader testing and a wider device/browser pass. Keyboard navigation and reduced-motion support are implemented; this is not a formal WCAG certification.
- Newsletter integration is not active. Add a real email platform and appropriate consent/unsubscribe behavior before displaying a working signup form.

## Scope notes

Live reference-page inspection and the existing mbilimwanza.com installation were unavailable due to connector authentication/network restrictions. This package follows the written brief and provides an original editorial implementation. No existing production backup is bundled and no hosting changes have been performed.
