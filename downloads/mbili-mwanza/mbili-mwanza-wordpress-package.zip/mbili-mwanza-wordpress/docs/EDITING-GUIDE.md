# Administrator editing guide

## Editing pages

Pages → Home / About / Contact / Privacy Policy → **Edit with Elementor**. Select headings, text, images, buttons, and containers to edit them normally. Use Elementor's desktop/tablet/mobile controls. Keep exactly one H1 per page. The portrait panels are image placeholders; click the Image widget to replace them. On mobile, check the image crop and text wrapping separately.

The theme uses fluid typography and the classes `hero-title`, `section-title`, `eyebrow`, `mm-body`, `mm-section`, `mm-row`, `mm-col`, `reveal`, and `clip-reveal`. Preserve these unless intentionally changing the design system. Layout containers can still be reordered and edited in Elementor.

## Shared designs

Templates → Saved Templates contains:

| Document | Controls |
|---|---|
| Mbili · Shared Header | Personal wordmark and navigation position; menu links come from Appearance → Menus |
| Mbili · Shared Footer | Closing CTA, footer layout, legal link, and your social links |
| Mbili · Work Archive | Portfolio heading, introductory copy, filters, cards, and query |
| Mbili · Single Case Study | Shared design for every `/work/{slug}/` page |
| Mbili · Writing Archive | `/writing/` when assigned as the WordPress posts page |
| Mbili · Single Article | Every native WordPress post |
| Mbili · Resource Archive | Resource library |
| Mbili · Single Resource | Individual resource detail and external destination |
| Mbili · 404 | Missing-page experience |

Edit these templates directly; do not insert a new copy per project. Dynamic widgets show empty editor placeholders until a preview post ID is supplied in the widget's Content panel. That ID affects the Elementor editor only, never the public query. Save shared design changes once to update all entries.

Dynamic Field widgets expose content source, semantic title tag, typography, color, and responsive content width. Dynamic Image widgets expose featured image or client logo plus responsive height. Listing widgets expose content type, entry count, featured-only mode, category filters, pagination, columns, gap, stagger, and card-title typography. Core Elementor Advanced controls remain available for spacing and responsive visibility.

Empty optional fields output no public content. Keep optional sections as individual dynamic widgets in a single container; do not wrap them in fixed-height decorative sections that could leave empty gaps.

## Publish a case study

1. Case Studies → Add New.
2. Enter the title, client name, logo, role, relationship type, confirmed date if known, and project summary. Set a featured image and excerpt.
3. Use the sidebar taxonomies for Industry, Services, and Project Category.
4. Enter the problem, solution, deliverables, and implementation. Do not add unsupported claims.
5. Under **Visual storytelling**, add rows. Choose full-width image, text, before/after pair, or an optional YouTube/Vimeo video. Select where rows appear: before problem, after problem, after solution, or after results. Move rows up/down to control ordering within each position. Several text and image rows allow a longer editorial story rather than a gallery appended at the end.
6. Use the Select image buttons to select media. The second image is used only for before/after pairs. Add captions and descriptive alternative text in the Media Library. Full-resolution image links open a new tab and support browser zoom. No third-party lightbox is required.
7. Add results only when available. Leave KPI cards, testimonial, and attribution empty unless you can support them and have permission. Blank sections are hidden.
8. Optionally select related case studies and add an external project URL.
9. Enable **Feature on homepage** for selected work. Preview, then Publish.

Publishing automatically creates `/work/project-slug/`, adds the entry to the Work archive, and includes featured entries in Home's Selected Work section. No Elementor duplication is needed. Use stable slugs; add server/SEO redirects if you rename an established URL.

The six starter organizations are drafts. Their inclusion does not assert a specific client relationship, scope, or result. Fill out the real relationship and evidence before publishing. Years without supplied evidence remain blank.

## Publish an article

Posts → Add New. Write with the native WordPress block editor. Add a title, excerpt, categories, featured image, and alternative text. Set the correct author and publication date. Publish. The shared template and Home/Writing listings populate automatically. The native body supports blocks and readable typography. Set your account's public display name to Mbili Mwanza when publishing as Mbili.

The supplied Writing page body is retained for manual editing, but WordPress's posts-page routing renders the shared Writing Archive document. Edit that saved template to change the visible archive.

## Add a resource

Resources → Add New. Enter the title, description in the editor, excerpt, cover image, category, type, and verified price or Free label. Add the destination URL. Flag affiliate relationships so the disclosure and sponsored/nofollow link attributes appear. Publish to add it to `/resources/` and the homepage resource grid. Checkout happens on the external destination; there is no shopping cart or payment storage in this package.

## Contact and newsletter

Contact form labels are in `mbili-platform/includes/forms-seo.php`; the introduction and button text are editable in the Elementor Inquiry Form widget. Recipient: Appearance → Customize → Mbili identity & social links. The form uses required fields, server validation, honeypot, signed timing token, nonce, consent, rate limiting, and redirect feedback. Feedback is announced through a status region. Do not cache the form page. Test both success and failure on your host.

Newsletter signup is intentionally inactive. When choosing a platform, replace that section with its official embed or a maintained integration, add consent and unsubscribe mechanisms, and update the privacy policy. Never present an inactive form as a working subscription.

## Search, social, and accessibility

Edit the Search & social description box on each page/post, or install one SEO plugin. Built-in metadata defers to Yoast, Rank Math, AIOSEO, and The SEO Framework. WordPress handles title tags, canonical singular URLs, and native XML sitemaps. Theme social settings populate Person schema; visible footer social links remain editable separately in Elementor.

Use heading levels in order; do not turn every large text block into an H1. Include meaningful link labels and image alt text. Check keyboard focus after layout edits. Motion respects reduced-motion settings; do not add third-party motion effects that override that preference.
