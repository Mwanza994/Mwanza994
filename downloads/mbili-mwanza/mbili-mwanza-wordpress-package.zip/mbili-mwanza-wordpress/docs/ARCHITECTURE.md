# Architecture and maintenance

## Separation of concerns

`mbili-editorial/` is the presentation theme. Its CSS, JS, native WordPress fallbacks, and template-slot renderer control design. It is standalone; Hello Elementor is not a parent dependency. Theme functionality uses standard hooks, template hierarchy, `wp_head()`, `wp_footer()`, image APIs, menu APIs, and Elementor's document renderer. Major designs live in saved Elementor documents imported by the companion plugin.

`mbili-platform/` owns content registration, custom metadata, publishing interfaces, dynamic Elementor widgets, form handling, metadata, and the explicit starter importer. Keep this plugin active when changing themes to preserve the publishing system. Deactivation leaves all stored content intact.

## Models

- `case_study`: public, REST-enabled CPT, archive `/work/`, single `/work/{slug}/`; title/editor/excerpt/thumbnail/revisions. Taxonomies: `mm_industry`, `mm_service`, `mm_project_category`.
- `mm_resource`: public, REST-enabled CPT, archive `/resources/`, single `/resources/{slug}/`; title/editor/excerpt/thumbnail/revisions. Taxonomy: `mm_resource_category`.
- Native `post`: standard WordPress publishing, categories, search, pagination, and feed.
- `_mm_data`: sanitized structured post metadata. Text, rich text, media attachment IDs, related entry IDs, ordered visual blocks, and at most four KPI cards. The metadata object is not exposed to unauthenticated REST writes. WordPress metadata revisions are enabled on supported core versions.
- `_mm_featured`: queryable scalar synchronized from `_mm_data.featured`; indexed using WordPress's standard metadata tables. No custom table required for this portfolio scale.
- `_mm_description`: editable fallback SEO description.

## Dynamic widgets

`mbili_field`, `mbili_media`, `mbili_listing`, `mbili_contact`, and `mbili_nav` are Elementor Widget_Base subclasses registered through `elementor/widgets/register`. The public content context comes from the queried object, so rendering a saved template never substitutes the template ID for a case study ID. Explicit editor preview IDs are available.

Case-study sections and flexible rows are rendered from metadata with standard escaping and `wp_kses_post`. Video embeds are restricted to YouTube/Vimeo hosts. Media uses attachment APIs for responsive srcset, width/height attributes, lazy loading below the fold, and eager loading of designated dynamic hero images. A static first-section portrait uses Elementor's native image loading behavior and should be checked on the deployment host.

The small custom widgets render dynamic structures. They do not hide entire pages inside HTML widgets. Page section headings, body content, buttons, portrait images, and container layouts use native Elementor widgets. Card sub-layout and field output markup are theme/plugin code, with exposed typography/layout controls where useful. Changing arbitrary card markup requires editing code; changing the shared arrangement and presentation does not.

## Elementor slots

Options `mbili_template_header`, `footer`, `case_study`, `work`, `single_post`, `writing`, `resources`, `resource`, and `404` reference `elementor_library` documents. This free-compatible shared-template system replaces the need to buy Theme Builder solely for the starter. It is not a counterfeit Pro feature and does not install Pro display conditions. Do not mix duplicated Pro conditions with these slots.

The importer has capability and nonce checks, requires explicit backup acknowledgment, and skips matching content. It does not fetch licenses, alter DNS, send mail, register subscribers, delete posts, or deploy anything. Reading settings change only when the installer checkbox is selected. Existing assigned menus are preserved.

## Fall-through behavior

With Elementor deactivated, native PHP templates render post content and case-study/resource fields. Articles and publishing data remain usable. Starter static pages retain a concise WordPress content fallback; elaborate Elementor layouts remain in metadata and return on reactivation. The custom functionality plugin must remain active to register the content models. If using another theme, the plugin appends case-study/resource data to native single content.

## Security and privacy

Admin writes require post-edit capability and a nonce. Inputs are bounded/sanitized; HTML uses WordPress's permitted post tags. URLs use URL sanitization/escaping. Inquiry messages are not saved as posts; `wp_mail()` sends to the configured recipient with a sanitized Reply-To. Signed timestamps, nonces, honeypot, consent, and HMAC-hashed remote-IP transients reduce common spam. No raw IP is stored by this plugin. A host/CDN may keep its own logs. Shared NAT networks can hit rate limits; adjust only after observing legitimate traffic. Do not trust forwarded-IP headers without a host-managed trust policy.

There is no analytics, font CDN, newsletter service, payment processor, or cookie banner in the default frontend. Add integrations only with an appropriate policy and consent review. The privacy page is a reviewable starter, not jurisdiction-specific legal advice.

## Design tokens

All public design assets are local. See DESIGN.md. Theme CSS supplies responsive defaults and reduced-motion handling. JavaScript progressively enhances the navigation, IntersectionObserver entry/text/image reveal, and optional bounded parallax on `[data-parallax]` elements. Anchors use native smooth scrolling. There is no scroll hijacking or page-transition router. A deliberate content entrance and section reveal are used in place of interception of browser navigation.

## Updates

Keep production customizations in a child theme or version-controlled fork to avoid overwriting changes. Back up before WordPress/Elementor upgrades, test on staging, and regenerate Elementor CSS. No development tooling or test databases are included in the install ZIPs. Project data survives presentation changes. There is no destructive uninstall hook.
