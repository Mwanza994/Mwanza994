# Design direction

An editorial personal platform: typography and narrative lead; companies support the personal story. The supplied references informed the requested direction, but live reference pages could not be inspected because the environment's external-domain policy blocked access. This is an original interpretation of the written brief, not a reproduction or a claim of a completed reference audit.

## Palette

| Token | Value | Purpose |
|---|---|---|
| Ink | `#201f1c` | Headlines, body, navigation, dark footer |
| Paper | `#f6f3ed` | Main background |
| Burnt orange | `#b54b2d` | Restrained emphasis, focus, arrows, highlighted type |
| Muted | `#68665f` | Supporting copy |
| Rule | `#d7d2c8` | Dividers and quiet structure |

The warm monochrome base and small accent are separate from Locath Tracks' company identity. Mbili's personal brand remains primary. There are no gradients or generic corporate-blue surfaces.

## Type and composition

Locally available Arial/Helvetica keeps loading simple and avoids a third-party font dependency. Georgia supplies an occasional editorial italic accent. Fluid headline sizes, tight display tracking, generous line spacing in body copy, broad margins, numbered section labels, full-width photo space, and staggered work cards provide hierarchy. Reading content is constrained to about 760px. Mobile uses its own stacking and headline scale rather than shrinking a desktop canvas.

Use authentic photographs, project covers, visual evidence, and captions to complete the art direction. The included neutral MM panel explicitly indicates a missing personal portrait and can be replaced in a native Elementor Image widget. No fake portrait, client artwork, testimonial, or invented work is bundled.

## Motion

Opacity/translate entry, scroll reveals, subtle clipping, card image scaling, link underlines, native smooth anchors, and optional limited parallax. No autoplay video, infinite decorative animation, scroll hijacking, or inter-page navigation interception. Reduced-motion preferences remove movement, transitions, and smooth scrolling. Without JavaScript, all content and navigation remain available.
