<?php
if (!defined('ABSPATH')) exit;
function mbili_register_content(){
 register_post_type('case_study',['labels'=>['name'=>'Case Studies','singular_name'=>'Case Study','add_new_item'=>'Add New Case Study','edit_item'=>'Edit Case Study'],'public'=>true,'show_in_rest'=>true,'has_archive'=>'work','rewrite'=>['slug'=>'work','with_front'=>false],'menu_icon'=>'dashicons-portfolio','supports'=>['title','editor','thumbnail','excerpt','revisions','custom-fields'],'show_in_nav_menus'=>true]);
 register_post_type('mm_resource',['labels'=>['name'=>'Resources','singular_name'=>'Resource','add_new_item'=>'Add New Resource'],'public'=>true,'show_in_rest'=>true,'has_archive'=>'resources','rewrite'=>['slug'=>'resources','with_front'=>false],'menu_icon'=>'dashicons-book','supports'=>['title','editor','thumbnail','excerpt','revisions','custom-fields']]);
 foreach(['mm_industry'=>['case_study','Industries'],'mm_service'=>['case_study','Services'],'mm_project_category'=>['case_study','Project Categories'],'mm_resource_category'=>['mm_resource','Resource Categories']] as $key=>$s){register_taxonomy($key,$s[0],['label'=>$s[1],'public'=>true,'hierarchical'=>true,'show_in_rest'=>true,'rewrite'=>['slug'=>str_replace('mm_','',$key)]]);}
 foreach(['case_study','mm_resource'] as $type){register_post_meta($type,'_mm_data',['single'=>true,'type'=>'object','show_in_rest'=>false,'revisions_enabled'=>true,'auth_callback'=>function(){return current_user_can('edit_posts');},'sanitize_callback'=>'mbili_clean_data']);}
}
add_action('init','mbili_register_content');
function mbili_fields(){return [
 'client'=>['Client / organization','text'],'logo'=>['Client logo','image'],'relationship'=>['Relationship type (e.g. employment, consultancy, founder)','text'],'role'=>['My role','text'],'project_date'=>['Project date (leave blank if unconfirmed)','text'],'summary'=>['Project summary','rich'],'problem_title'=>['Problem headline','text'],'problem'=>['Detailed problem description','rich'],'solution_title'=>['Solution headline','text'],'solution'=>['Detailed solution description','rich'],'deliverables'=>['Services / deliverables','rich'],'implementation'=>['Implementation details','rich'],'results_title'=>['Results headline','text'],'results'=>['Detailed outcomes — verified facts only','rich'],'evidence'=>['Supporting evidence','rich'],'testimonial'=>['Client testimonial — optional, permission required','textarea'],'testimonial_by'=>['Testimonial attribution','text'],'external_url'=>['External project URL','url'],'related'=>['Related case studies','related'],'featured'=>['Feature on homepage','checkbox'],
 'resource_type'=>['Resource type (owned product, recommended book, tool, etc.)','text'],'price'=>['Price or Free label (leave blank if unconfirmed)','text'],'destination'=>['Resource destination URL','url'],'affiliate'=>['Affiliate link — display disclosure','checkbox']];}
function mbili_clean_data($input){
 if(!is_array($input))return []; if(isset($input['related'])&&is_array($input['related']))$input['related']=implode(',',array_map('absint',$input['related'])); $out=[];
 foreach(mbili_fields() as $k=>$f){$v=$input[$k]??'';if(is_array($v))continue;$out[$k]=match($f[1]){'image'=>absint($v),'checkbox'=>!empty($v)?1:0,'url'=>esc_url_raw($v),'rich'=>wp_kses_post($v),'textarea'=>sanitize_textarea_field($v),default=>sanitize_text_field($v)};}
 $out['related']=implode(',',array_filter(array_map('absint',explode(',',(string)($out['related']??'')))));
 foreach(['blocks','kpis'] as $key){$out[$key]=[];foreach(array_slice((array)($input[$key]??[]),0,$key==='kpis'?4:60) as $row){if(!is_array($row))continue;if($key==='kpis'){$out[$key][]=['value'=>sanitize_text_field($row['value']??''),'label'=>sanitize_text_field($row['label']??'')];}else{$type=in_array($row['type']??'', ['image','text','pair','video'],true)?$row['type']:'image';$out[$key][]=['type'=>$type,'position'=>in_array($row['position']??'',['before_problem','after_problem','after_solution','after_results'],true)?$row['position']:'after_solution','image'=>absint($row['image']??0),'image2'=>absint($row['image2']??0),'caption'=>sanitize_text_field($row['caption']??''),'body'=>wp_kses_post($row['body']??''),'video'=>esc_url_raw($row['video']??'')];}}}
 return $out;
}
function mbili_data($id=0){$d=get_post_meta($id?:get_the_ID(),'_mm_data',true);return is_array($d)?$d:[];}
add_action('add_meta_boxes',function(){foreach(['case_study','mm_resource'] as $type)add_meta_box('mm-publishing','Publishing details','mbili_meta_box',$type,'normal','high');});
function mbili_meta_box($post){
 wp_nonce_field('mm_save','mm_nonce');$data=mbili_data($post->ID);$resource=$post->post_type==='mm_resource';
 echo '<p>Use the title, featured image, taxonomy panels, and excerpt alongside these fields. Leave unverified results and optional sections blank. <strong>Publish without opening Elementor.</strong></p>';
 foreach(mbili_fields() as $key=>$f){$is_resource=in_array($key,['resource_type','price','destination','affiliate'],true);if($resource!==$is_resource)continue;
 $v=$data[$key]??'';echo '<div class="mm-admin-field"><label for="mm-'.esc_attr($key).'"><strong>'.esc_html($f[0]).'</strong></label>';
 if($f[1]==='rich'){wp_editor($v,'mm_'.$key,['textarea_name'=>'mm_data['.$key.']','media_buttons'=>false,'textarea_rows'=>5,'teeny'=>true]);}
 elseif($f[1]==='textarea')echo '<textarea id="mm-'.esc_attr($key).'" name="mm_data['.esc_attr($key).']" rows="4" class="widefat">'.esc_textarea($v).'</textarea>';
 elseif($f[1]==='image')echo '<div><input id="mm-'.esc_attr($key).'" type="number" min="0" name="mm_data['.esc_attr($key).']" value="'.esc_attr($v).'" class="mm-image-id"><button type="button" class="button mm-select-image">Select image</button></div>';
 elseif($f[1]==='related'){echo '<select multiple class="widefat" size="6" id="mm-related" name="mm_data[related][]">';$selected_ids=array_map('absint',explode(',',(string)$v));foreach(get_posts(['post_type'=>'case_study','post_status'=>['publish','draft'],'numberposts'=>100,'post__not_in'=>[$post->ID]])as $related)echo '<option value="'.esc_attr($related->ID).'" '.selected(in_array($related->ID,$selected_ids,true),true,false).'>'.esc_html($related->post_title).'</option>';echo '</select><small>Hold Ctrl / Command to select multiple.</small>';}
 elseif($f[1]==='checkbox')echo '<input id="mm-'.esc_attr($key).'" type="checkbox" name="mm_data['.esc_attr($key).']" value="1" '.checked($v,1,false).'>';
 else echo '<input class="widefat" id="mm-'.esc_attr($key).'" type="'.esc_attr($f[1]).'" name="mm_data['.esc_attr($key).']" value="'.esc_attr($v).'">';echo '</div>';
 }
 if(!$resource){echo '<h3>Visual storytelling</h3><p>Add media or text between the problem, solution, and results. Reorder rows with Move up / Move down. Image IDs can be selected from the Media Library. Videos accept YouTube or Vimeo URLs only.</p><div class="mm-repeater" data-kind="blocks">';foreach(($data['blocks']??[]) as $i=>$row)mbili_admin_row('blocks',$i,$row);echo '</div><button type="button" class="button mm-add-row" data-kind="blocks">Add visual / text section</button>';
 echo '<h3>Optional KPI cards (maximum four)</h3><p>Only enter metrics you can support with evidence.</p><div class="mm-repeater" data-kind="kpis">';foreach(($data['kpis']??[]) as $i=>$row)mbili_admin_row('kpis',$i,$row);echo '</div><button type="button" class="button mm-add-row" data-kind="kpis">Add KPI</button>';}
}
function mbili_admin_row($kind,$i,$row=[]){
 echo '<fieldset class="mm-repeat-row"><legend>'.($kind==='kpis'?'KPI':'Story section').'</legend>';
 $fields=$kind==='kpis'?['value'=>'Value','label'=>'Label']:['type'=>'Layout','position'=>'Place after / before','image'=>'Image ID','image2'=>'Second / after image ID','caption'=>'Caption','body'=>'Text / description','video'=>'Video URL'];
 foreach($fields as $k=>$label){$name='mm_data['.$kind.']['.$i.']['.$k.']';$v=$row[$k]??'';echo '<label>'.esc_html($label);
 if($k==='type'||$k==='position'){$opts=$k==='type'?['image'=>'Full width image','text'=>'Editorial text','pair'=>'Before / after image pair','video'=>'Video']:['before_problem'=>'Before problem','after_problem'=>'After problem','after_solution'=>'After solution','after_results'=>'After results'];echo '<select name="'.esc_attr($name).'">';foreach($opts as $val=>$l)echo '<option value="'.esc_attr($val).'" '.selected($v,$val,false).'>'.esc_html($l).'</option>';echo '</select>';}
 elseif($k==='body')echo '<textarea name="'.esc_attr($name).'" rows="4">'.esc_textarea($v).'</textarea>';
 else {echo '<input type="'.(in_array($k,['image','image2'],true)?'number':($k==='video'?'url':'text')).'" name="'.esc_attr($name).'" value="'.esc_attr($v).'" '.(in_array($k,['image','image2'],true)?'class="mm-image-id" min="0"':'').'>';if(in_array($k,['image','image2'],true))echo '<button type="button" class="button mm-select-image">Select image</button>';}
 echo '</label>';}
 echo '<div><button type="button" class="button mm-up">Move up</button> <button type="button" class="button mm-down">Move down</button> <button type="button" class="button mm-remove">Remove</button></div></fieldset>';
}
add_action('save_post',function($id){
 if(!isset($_POST['mm_nonce'])||!wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mm_nonce'])),'mm_save')||!current_user_can('edit_post',$id)||wp_is_post_revision($id)||wp_is_post_autosave($id))return;
 if(!in_array(get_post_type($id),['case_study','mm_resource'],true))return;
 update_post_meta($id,'_mm_data',mbili_clean_data(wp_unslash($_POST['mm_data']??[])));
});
add_action('admin_enqueue_scripts',function($hook){$screen=get_current_screen();if(!$screen||!in_array($screen->post_type,['case_study','mm_resource'],true))return;wp_enqueue_media();wp_enqueue_style('mm-admin',MBILI_PLATFORM_URL.'assets/admin.css',[],'1.0.0');wp_enqueue_script('mm-admin',MBILI_PLATFORM_URL.'assets/admin.js',['jquery'],'1.0.0',true);});
add_action('admin_footer',function(){ $s=get_current_screen();if(!$s||!in_array($s->post_type,['case_study','mm_resource'],true))return;foreach(['blocks','kpis']as $kind){echo '<template id="mm-template-'.esc_attr($kind).'">';mbili_admin_row($kind,'__INDEX__');echo '</template>';}});
