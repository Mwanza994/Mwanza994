<?php
if (!defined('ABSPATH')) exit;
function mbili_context_id(){return is_singular()?get_queried_object_id():get_the_ID();}
function mbili_media($id,$size='large',$class='',$eager=false){
 if(!$id||!wp_attachment_is_image($id))return '';
 return wp_get_attachment_image($id,$size,false,['class'=>$class,'loading'=>$eager?'eager':'lazy','decoding'=>'async']);
}
function mbili_story_blocks($id,$position='after_solution'){
 $d=mbili_data($id);$html='';
 foreach($d['blocks']??[] as $b){if(($b['position']??'after_solution')!==$position)continue;$part='';$caption=$b['caption']??'';
 if(($b['type']??'')==='text'){if(!empty($b['body']))$part='<div class="prose">'.wpautop(wp_kses_post($b['body'])).'</div>';}
 elseif(($b['type']??'')==='video'){
  $url=$b['video']??'';$host=strtolower((string)wp_parse_url($url,PHP_URL_HOST));
  if(in_array($host,['youtube.com','www.youtube.com','youtu.be','vimeo.com','www.vimeo.com'],true)){$embed=wp_oembed_get($url);if($embed)$part='<figure class="wp-embed-aspect-16-9 wp-has-aspect-ratio">'.$embed.'</figure>';}
 }else{
  $img=mbili_media($b['image']??0,'mbili-hero');if($img){$full=wp_get_attachment_url($b['image']);$part='<a href="'.esc_url($full).'" target="_blank" rel="noopener" aria-label="'.esc_attr($caption?:'View full-resolution project image (opens in a new tab)').'">'.$img.'</a>';}
  if(($b['type']??'')==='pair'&&!empty($b['image2'])){$img2=mbili_media($b['image2'],'large');if($img2)$part='<div class="paired"><figure>'.$part.'<figcaption>Before</figcaption></figure><figure><a href="'.esc_url(wp_get_attachment_url($b['image2'])).'" target="_blank" rel="noopener" aria-label="View after image at full resolution (opens in a new tab)">'.$img2.'</a><figcaption>After</figcaption></figure></div>';}
 }
 if($part){$html.='<figure>'.$part.($caption?'<figcaption>'.esc_html($caption).'</figcaption>':'').'</figure>';}
 }
 return $html?'<div class="case-showcase">'.$html.'</div>':'';
}
function mbili_metadata($id){$d=mbili_data($id);$out='';foreach(['client'=>'Organization','relationship'=>'Relationship','role'=>'My role','project_date'=>'Date'] as $key=>$label){if(!empty($d[$key]))$out.='<div><dt>'.esc_html($label).'</dt><dd>'.esc_html($d[$key]).'</dd></div>';}
 foreach(['mm_industry'=>'Industry','mm_service'=>'Services']as $tax=>$label){$terms=get_the_terms($id,$tax);if($terms&&!is_wp_error($terms))$out.='<div><dt>'.esc_html($label).'</dt><dd>'.esc_html(implode(', ',wp_list_pluck($terms,'name'))).'</dd></div>';}
 return $out?'<dl class="case-metadata">'.$out.'</dl>':'';
}
function mbili_case_section($id,$field){$d=mbili_data($id);$v=$d[$field]??'';if(!$v)return '';$titles=['summary'=>'Overview','problem'=>'The problem','solution'=>'The solution','deliverables'=>'Deliverables','implementation'=>'Implementation','results'=>'Results & impact','evidence'=>'Supporting evidence'];$heading=$d[$field.'_title']??($titles[$field]??'');$heading=$heading?:($titles[$field]??'');return '<section class="case-section"><h2>'.esc_html($heading).'</h2><div class="prose">'.wpautop(wp_kses_post($v)).'</div></section>';}
function mbili_kpis($id){$html='';foreach(mbili_data($id)['kpis']??[]as $r){if(!empty($r['value'])&&!empty($r['label']))$html.='<div><span class="kpi-value">'.esc_html($r['value']).'</span><span class="kpi-label">'.esc_html($r['label']).'</span></div>';}return $html?'<div class="kpi-grid">'.$html.'</div>':'';}
function mbili_testimonial($id){$d=mbili_data($id);return !empty($d['testimonial'])?'<blockquote class="case-quote"><p>'.esc_html($d['testimonial']).'</p>'.(!empty($d['testimonial_by'])?'<cite>'.esc_html($d['testimonial_by']).'</cite>':'').'</blockquote>':'';}
function mbili_case_body($id){$out=mbili_metadata($id).mbili_case_section($id,'summary').mbili_story_blocks($id,'before_problem');foreach(['problem','solution','results']as $f){$out.=mbili_case_section($id,$f);if($f==='solution')$out.=mbili_case_section($id,'deliverables').mbili_case_section($id,'implementation');if($f==='results')$out.=mbili_kpis($id).mbili_testimonial($id).mbili_case_section($id,'evidence');$out.=mbili_story_blocks($id,'after_'.$f);}$d=mbili_data($id);if(!empty($d['external_url']))$out.='<a class="button" href="'.esc_url($d['external_url']).'">Visit project ↗</a>';return $out;}
function mbili_listing($atts=[]){
 $a=wp_parse_args($atts,['type'=>'post','count'=>6,'featured'=>false,'filter'=>false,'paginate'=>false,'exclude'=>0,'related'=>false]);
 $type=in_array($a['type'],['post','case_study','mm_resource'],true)?$a['type']:'post';$tax=$type==='case_study'?'mm_project_category':($type==='mm_resource'?'mm_resource_category':'category');$param=$type==='post'?'article_category':($type==='case_study'?'project_category':'resource_category');
 $current=isset($_GET[$param])?sanitize_title(wp_unslash($_GET[$param])):'';$search=$type==='post'&&isset($_GET['article_search'])?sanitize_text_field(wp_unslash($_GET['article_search'])):'';
 $paged=$a['paginate']?max(1,absint(get_query_var('paged')),absint($_GET['mm_page']??1)):1;
 $args=['post_type'=>$type,'post_status'=>'publish','posts_per_page'=>max(1,min(24,absint($a['count']))),'paged'=>$paged,'ignore_sticky_posts'=>true,'no_found_rows'=>!$a['paginate']];
 if($a['exclude'])$args['post__not_in']=[absint($a['exclude'])];
 // Featured uses a separate queryable scalar derived from the structured content at save.
 if($a['featured'])$args['meta_query']=[['key'=>'_mm_featured','value'=>'1']];
 if($current)$args['tax_query']=[['taxonomy'=>$tax,'field'=>'slug','terms'=>$current]];
 if($search)$args['s']=$search;
 if($a['related']){$d=mbili_data(mbili_context_id());$ids=array_filter(array_map('absint',explode(',',$d['related']??'')));$args['post__not_in']=[mbili_context_id()];if($ids){$args['post__in']=$ids;$args['orderby']='post__in';}}
 $query=new WP_Query($args);$html='';
 if($a['filter']){
  $base=remove_query_arg([$param,'mm_page','paged']);$base=preg_replace('~/page/\d+/?~','/',$base);
  $html.='<nav class="filter-bar" aria-label="Filter '.esc_attr($type==='post'?'articles':'entries').'"><a href="'.esc_url($base).'"'.(!$current?' aria-current="page"':'').'>All</a>';
  $terms=get_terms(['taxonomy'=>$tax,'hide_empty'=>true]);if(!is_wp_error($terms))foreach($terms as $term)$html.='<a href="'.esc_url(add_query_arg($param,$term->slug,$base)).'"'.($current===$term->slug?' aria-current="page"':'').'>'.esc_html($term->name).'</a>';$html.='</nav>';
  if($type==='post'){$html.='<form class="search-form" method="get" action="'.esc_url($base).'"><label>Search writing<div><input type="search" name="article_search" value="'.esc_attr($search).'" placeholder="Find an idea…"><button type="submit">Search ↗</button></div></label>'.($current?'<input type="hidden" name="article_category" value="'.esc_attr($current).'">':'').'</form>';}
 }
 if(!$query->have_posts())return $html.'<div class="empty-state">'.($search||$current?'No entries match your selection. Try another category or search.':($type==='post'?'New writing will appear here when published.':($type==='case_study'?'Case studies are being prepared. Explore the story behind the work on the About page.':'The resource library is being curated. New entries will appear here when published.'))).'</div>';
 $html.='<div class="card-grid">';while($query->have_posts()){$query->the_post();$id=get_the_ID();$d=mbili_data($id);$title=get_the_title();$image=mbili_media(get_post_thumbnail_id(),'mbili-card');if(!$image)$image='<span class="cover-letter" aria-hidden="true">'.esc_html(mb_substr($title,0,1)).'</span>';
 $html.='<article class="editorial-card"><a href="'.esc_url(get_permalink()).'" class="card-image" tabindex="-1" aria-hidden="true">'.$image.'</a><div class="card-meta">';
 if($type==='post')$html.='<time datetime="'.esc_attr(get_the_date('c')).'">'.esc_html(get_the_date('M j, Y')).'</time>';
 elseif($type==='case_study'&&!empty($d['client']))$html.='<span>'.esc_html($d['client']).'</span>';
 elseif($type==='mm_resource')$html.='<span>'.esc_html($d['resource_type']??'').'</span><span>'.esc_html($d['price']??'').'</span>';
 $terms=get_the_terms($id,$tax);if($terms&&!is_wp_error($terms))$html.='<span>'.esc_html(implode(' / ',wp_list_pluck($terms,'name'))).'</span>';
 if($type==='case_study'){foreach(['mm_industry','mm_service'] as $t){$ts=get_the_terms($id,$t);if($ts&&!is_wp_error($ts))$html.='<span>'.esc_html(implode(' / ',wp_list_pluck($ts,'name'))).'</span>';}}
 $html.='</div><h3><a href="'.esc_url(get_permalink()).'">'.esc_html($title).'<span class="card-arrow" aria-hidden="true">↗</span></a></h3><p class="card-excerpt">'.esc_html(wp_trim_words(get_the_excerpt(),24)).'</p></article>';
 }wp_reset_postdata();$html.='</div>';
 if($a['paginate']&&$query->max_num_pages>1){$base=remove_query_arg('mm_page');$base=preg_replace('~/page/\d+/?~','/',$base);$links=paginate_links(['base'=>add_query_arg('mm_page','%#%',$base),'format'=>'','current'=>$paged,'total'=>$query->max_num_pages,'type'=>'plain']);$html.='<nav class="pagination" aria-label="Pagination">'.$links.'</nav>';}
 return $html;
}
add_action('updated_post_meta',function($mid,$id,$key,$value){if($key==='_mm_data')update_post_meta($id,'_mm_featured',!empty($value['featured'])?'1':'0');},10,4);
add_action('added_post_meta',function($mid,$id,$key,$value){if($key==='_mm_data')update_post_meta($id,'_mm_featured',!empty($value['featured'])?'1':'0');},10,4);
add_shortcode('mbili_listing',function($atts){$atts=shortcode_atts(['type'=>'post','count'=>6,'featured'=>'','filter'=>'','paginate'=>''],$atts);foreach(['featured','filter','paginate']as $k)$atts[$k]=filter_var($atts[$k],FILTER_VALIDATE_BOOLEAN);return mbili_listing($atts);});
