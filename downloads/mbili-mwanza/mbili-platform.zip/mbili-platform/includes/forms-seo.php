<?php
if (!defined('ABSPATH')) exit;
function mbili_contact_form($button='Send inquiry ↗'){
 $status=isset($_GET['inquiry'])?sanitize_key($_GET['inquiry']):'';
 $messages=['sent'=>'Thank you. Your inquiry has been accepted for delivery.','invalid'=>'Please complete all required fields with a valid email address and consent.','slow'=>'Please take a moment to review your message, then try again.','limited'=>'Too many attempts. Please try again in 15 minutes.','expired'=>'This form has expired. Reload the page and try again.','failed'=>'Your inquiry could not be sent. Please try again later.'];
 $out=isset($messages[$status])?'<div class="form-notice" role="status" tabindex="-1" id="inquiry-feedback">'.esc_html($messages[$status]).'</div>':'';
 $time=time();$out.='<form class="mm-contact-form" method="post" action="'.esc_url(admin_url('admin-post.php')).'"><input type="hidden" name="action" value="mbili_inquiry"><input type="hidden" name="mm_return" value="'.esc_url((is_singular()?get_permalink(get_queried_object_id()):home_url('/contact/'))).'">'.wp_nonce_field('mbili_inquiry','mm_form_nonce',true,false).'<input type="hidden" name="mm_started" value="'.esc_attr($time).'"><input type="hidden" name="mm_signature" value="'.esc_attr(wp_hash('mm_form_'.$time)).'">';
 $out.='<div class="hp-wrap" aria-hidden="true"><label>Leave this field empty<input name="website_confirm" tabindex="-1" autocomplete="off"></label></div>';
 $out.='<label>Your name *<input name="mm_name" autocomplete="name" maxlength="120" required></label><label>Email address *<input name="mm_email" type="email" autocomplete="email" maxlength="190" required></label><label>Organization<input name="mm_organization" autocomplete="organization" maxlength="190"></label><label>Inquiry type *<select name="mm_type" required><option value="">Select a pathway</option><option>Consulting</option><option>Collaboration</option><option>Media</option><option>Speaking</option></select></label><label class="full">What would you like to build? *<textarea name="mm_message" minlength="20" maxlength="6000" rows="6" required></textarea></label><label class="consent full"><input type="checkbox" name="mm_consent" value="1" required><span>I agree that my information may be used to respond to this inquiry. <a href="'.esc_url(home_url('/privacy-policy/')).'">Read the privacy policy</a>.</span></label><button class="button full" type="submit">'.esc_html($button).'</button></form>';
 return $out;
}
add_shortcode('mbili_contact',function(){return mbili_contact_form();});
function mbili_form_value($key){$value=$_POST[$key]??'';return is_string($value)?wp_unslash($value):'';}
function mbili_handle_inquiry(){
 $return=wp_validate_redirect(esc_url_raw(mbili_form_value('mm_return')),home_url('/contact/'));
 $finish=function($status)use($return){nocache_headers();wp_safe_redirect(add_query_arg('inquiry',$status,remove_query_arg('inquiry',$return)).'#inquiry-feedback');exit;};
 if($_SERVER['REQUEST_METHOD']!=='POST')$finish('invalid');
 if(!wp_verify_nonce(sanitize_text_field(mbili_form_value('mm_form_nonce')),'mbili_inquiry'))$finish('expired');
 $started=absint(mbili_form_value('mm_started'));$signature=sanitize_text_field(mbili_form_value('mm_signature'));
 if(!$started||!hash_equals(wp_hash('mm_form_'.$started),$signature)||time()-$started>DAY_IN_SECONDS)$finish('expired');
 if(!empty($_POST['website_confirm'])||time()-$started<4)$finish('slow');
 $name=sanitize_text_field(mbili_form_value('mm_name'));$email=sanitize_email(mbili_form_value('mm_email'));$org=sanitize_text_field(mbili_form_value('mm_organization'));$type=sanitize_text_field(mbili_form_value('mm_type'));$message=sanitize_textarea_field(mbili_form_value('mm_message'));
 if(!$name||strlen($name)>120||!is_email($email)||strlen($email)>190||strlen($org)>190||strlen($message)<20||strlen($message)>6000||!in_array($type,['Consulting','Collaboration','Media','Speaking'],true)||($_POST['mm_consent']??'')!=='1')$finish('invalid');
 $ip=sanitize_text_field($_SERVER['REMOTE_ADDR']??'unknown');$key='mm_rate_'.hash_hmac('sha256',$ip,wp_salt('nonce'));$tries=(int)get_transient($key);if($tries>=5)$finish('limited');set_transient($key,$tries+1,15*MINUTE_IN_SECONDS);
 $recipient=get_theme_mod('mbili_contact_email')?:get_option('admin_email');if(!is_email($recipient))$finish('failed');
 $body="Name: $name\nEmail: $email\nOrganization: $org\nInquiry: $type\n\n$message\n\nConsent to respond was supplied via the website inquiry form.";
 $sent=wp_mail($recipient,'Website inquiry: '.$type,$body,['Reply-To: '.$email]);$finish($sent?'sent':'failed');
}
add_action('admin_post_mbili_inquiry','mbili_handle_inquiry');add_action('admin_post_nopriv_mbili_inquiry','mbili_handle_inquiry');
// Prevent stale nonce / signed timestamps on contact pages; also exclude /contact/ at the CDN.
add_action('template_redirect',function(){if(is_page('contact')){if(!defined('DONOTCACHEPAGE'))define('DONOTCACHEPAGE',true);nocache_headers();}});
function mbili_has_seo_plugin(){return defined('WPSEO_VERSION')||defined('RANK_MATH_VERSION')||defined('AIOSEO_VERSION')||defined('THE_SEO_FRAMEWORK_VERSION');}
add_action('add_meta_boxes',function(){foreach(['page','post','case_study','mm_resource']as $type)add_meta_box('mm-seo','Search & social description',function($p){wp_nonce_field('mm_seo','mm_seo_nonce');echo '<p>Optional description. If an SEO plugin is active, manage metadata there instead.</p><label for="mm-description">Meta description</label><textarea class="widefat" rows="3" maxlength="300" id="mm-description" name="mm_description">'.esc_textarea(get_post_meta($p->ID,'_mm_description',true)).'</textarea>';},$type,'side');});
add_action('save_post',function($id){if(isset($_POST['mm_seo_nonce'])&&wp_verify_nonce(sanitize_text_field(wp_unslash($_POST['mm_seo_nonce'])),'mm_seo')&&current_user_can('edit_post',$id)&&!wp_is_post_revision($id)&&!wp_is_post_autosave($id))update_post_meta($id,'_mm_description',sanitize_textarea_field(wp_unslash($_POST['mm_description']??'')));});
add_action('wp_head',function(){
 if(mbili_has_seo_plugin()||is_404()||is_search())return;
 $id=get_queried_object_id();$title=wp_get_document_title();$description=is_singular()?get_post_meta($id,'_mm_description',true):'';
 if(!$description&&is_singular())$description=wp_trim_words(wp_strip_all_tags(get_the_excerpt($id)),30,'');
 if(!$description)$description='Mbili Mwanza — Entrepreneur. Strategist. Builder. I build businesses, develop systems, and share what I learn along the way.';
 $url=is_singular()?get_permalink($id):home_url(wp_parse_url(wp_unslash($_SERVER['REQUEST_URI']??'/'),PHP_URL_PATH));
 if(!is_singular()&&!empty($_GET['mm_page']))$url=add_query_arg('mm_page',absint($_GET['mm_page']),$url);
 echo '<meta name="description" content="'.esc_attr($description).'">';
 if(!is_singular())echo '<link rel="canonical" href="'.esc_url($url).'">';
 foreach(['og:title'=>$title,'og:description'=>$description,'og:url'=>$url,'og:type'=>is_singular('post')?'article':'website','og:site_name'=>'Mbili Mwanza']as $k=>$v)echo '<meta property="'.esc_attr($k).'" content="'.esc_attr($v).'">';
 echo '<meta name="twitter:card" content="summary_large_image">';
 if(is_singular()&&has_post_thumbnail($id))echo '<meta property="og:image" content="'.esc_url(wp_get_attachment_image_url(get_post_thumbnail_id($id),'large')).'">';
 $schema=[];
 if(is_front_page()||is_page('about')){$person=['@context'=>'https://schema.org','@type'=>'Person','@id'=>home_url('/#person'),'name'=>'Mbili Mwanza','url'=>home_url('/'),'description'=>'Entrepreneur. Strategist. Builder.'];$same=[];foreach(['linkedin','instagram']as $key){$u=get_theme_mod('mbili_'.$key);if($u)$same[]=esc_url_raw($u);}if($same)$person['sameAs']=$same;$schema=$person;}
 if(is_singular('post')){$schema=['@context'=>'https://schema.org','@type'=>'Article','headline'=>get_the_title($id),'datePublished'=>get_the_date('c',$id),'dateModified'=>get_the_modified_date('c',$id),'mainEntityOfPage'=>$url,'author'=>['@type'=>'Person','name'=>get_the_author_meta('display_name',get_post_field('post_author',$id))]];if(has_post_thumbnail($id))$schema['image']=wp_get_attachment_image_url(get_post_thumbnail_id($id),'full');}
 if($schema)echo '<script type="application/ld+json">'.wp_json_encode($schema,JSON_HEX_TAG|JSON_HEX_AMP|JSON_HEX_APOS|JSON_HEX_QUOT).'</script>';
},5);
