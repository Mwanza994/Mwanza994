<?php
if (!defined('ABSPATH')) exit;
trait Mbili_Widget_Style {
 protected function mm_style(){
  $this->start_controls_section('mm_style',['label'=>'Typography & spacing','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
  $this->add_control('text_color',['label'=>'Text color','type'=>\Elementor\Controls_Manager::COLOR,'selectors'=>['{{WRAPPER}}'=>'color: {{VALUE}};']]);
  $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),['name'=>'mm_typography','selector'=>'{{WRAPPER}} .mm-field, {{WRAPPER}} .mm-field h1, {{WRAPPER}} .mm-field h2, {{WRAPPER}} .mm-field h3']);
  $this->add_responsive_control('content_width',['label'=>'Content width','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>200,'max'=>1600]],'selectors'=>['{{WRAPPER}} .mm-field'=>'max-width: {{SIZE}}{{UNIT}};']]);
  $this->end_controls_section();
 }
}
class Mbili_Field_Widget extends \Elementor\Widget_Base {
 use Mbili_Widget_Style;
 public function get_name(){return 'mbili_field';}public function get_title(){return 'Mbili · Dynamic field';}public function get_icon(){return 'eicon-database';}public function get_categories(){return ['general'];}
 protected function register_controls(){
  $this->start_controls_section('content',['label'=>'Dynamic content']);
  $options=['post_title'=>'Post / project title','post_content'=>'Native article content','post_excerpt'=>'Excerpt','post_meta'=>'Article date, author & categories','author_bio'=>'Author biography','metadata'=>'Project information','summary'=>'Project overview','problem'=>'Problem section','solution'=>'Solution section','deliverables'=>'Deliverables','implementation'=>'Implementation','results'=>'Results','evidence'=>'Supporting evidence','kpis'=>'KPI cards','testimonial'=>'Optional testimonial','media_before_problem'=>'Visuals: before problem','media_after_problem'=>'Visuals: after problem','media_after_solution'=>'Visuals: after solution','media_after_results'=>'Visuals: after results','resource_details'=>'Resource details & destination','external_url'=>'External project link'];
  foreach(mbili_fields()as $k=>$f){if(!isset($options[$k])&&$f[1]!=='image')$options[$k]=$f[0];}
  $this->add_control('field',['label'=>'Content source','type'=>\Elementor\Controls_Manager::SELECT,'options'=>$options,'default'=>'post_title']);
  $this->add_control('tag',['label'=>'Heading tag (title only)','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['h1'=>'H1','h2'=>'H2','h3'=>'H3','p'=>'Paragraph'],'default'=>'h1']);
  $this->add_control('preview_id',['label'=>'Editor preview post ID','description'=>'Set to a case study or post ID to preview real data while editing this shared template. Not used on the public site.','type'=>\Elementor\Controls_Manager::NUMBER,'min'=>1]);
  $this->end_controls_section();$this->mm_style();
 }
 protected function render(){
  $s=$this->get_settings_for_display();$id=mbili_context_id();if(\Elementor\Plugin::instance()->editor->is_edit_mode()&&!empty($s['preview_id']))$id=absint($s['preview_id']);
  $f=$s['field'];$d=mbili_data($id);$html='';
  if($f==='post_title'){$tag=in_array($s['tag'],['h1','h2','h3','p'],true)?$s['tag']:'h1';$html='<'.$tag.'>'.esc_html(get_the_title($id)).'</'.$tag.'>';}
  elseif($f==='post_content'){$raw=get_post_field('post_content',$id);$html=wpautop(wp_kses_post(do_blocks($raw)));}
  elseif($f==='post_excerpt')$html='<p>'.esc_html(get_the_excerpt($id)).'</p>';
  elseif($f==='post_meta'){$cats=get_the_category($id);$names=wp_list_pluck($cats,'name');$html='<div class="eyebrow">'.esc_html(implode(' / ',$names)).' · <time datetime="'.esc_attr(get_the_date('c',$id)).'">'.esc_html(get_the_date('M j, Y',$id)).'</time></div><p>By '.esc_html(get_the_author_meta('display_name',get_post_field('post_author',$id))).'</p>';}
  elseif($f==='author_bio')$html='<aside class="author-bio"><h2>Written by Mbili Mwanza</h2><p>Entrepreneur. Strategist. Builder. I build businesses, develop systems, and share what I learn along the way.</p><a href="'.esc_url(home_url('/about/')).'">Read my story ↗</a></aside>';
  elseif($f==='metadata')$html=mbili_metadata($id);
  elseif(in_array($f,['summary','problem','solution','deliverables','implementation','results','evidence'],true))$html=mbili_case_section($id,$f);
  elseif(str_starts_with($f,'media_'))$html=mbili_story_blocks($id,substr($f,6));
  elseif($f==='kpis')$html=mbili_kpis($id);
  elseif($f==='testimonial')$html=mbili_testimonial($id);
  elseif($f==='external_url'){if(!empty($d[$f]))$html='<a class="button" href="'.esc_url($d[$f]).'">Visit project ↗</a>';}
  elseif($f==='resource_details'){$html='<p class="eyebrow">'.esc_html($d['resource_type']??'').'</p>';if(!empty($d['price']))$html.='<p>'.esc_html($d['price']).'</p>';if(!empty($d['affiliate']))$html.='<p class="affiliate-note">Affiliate disclosure: I may earn a commission if you purchase through this link.</p>';if(!empty($d['destination']))$html.='<a class="button" href="'.esc_url($d['destination']).'"'.(!empty($d['affiliate'])?' rel="sponsored nofollow"':'').'>Explore resource ↗</a>';}
  elseif(!empty($d[$f]))$html='<p>'.esc_html($d[$f]).'</p>';
  if($html)echo '<div class="mm-field">'.$html.'</div>';
  elseif(\Elementor\Plugin::instance()->editor->is_edit_mode())echo '<div class="empty-state">'.esc_html('Optional field: '.$f.'. Set a preview post ID to view data. Hidden on the public site when empty.').'</div>';
 }
}
class Mbili_Listing_Widget extends \Elementor\Widget_Base{
 public function get_name(){return 'mbili_listing';}public function get_title(){return 'Mbili · Dynamic listing';}public function get_icon(){return 'eicon-posts-grid';}public function get_categories(){return ['general'];}
 protected function register_controls(){
  $this->start_controls_section('content',['label'=>'Query']);
  $this->add_control('type',['label'=>'Content type','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['post'=>'Writing','case_study'=>'Case studies','mm_resource'=>'Resources'],'default'=>'case_study']);
  $this->add_control('count',['label'=>'Entries per page','type'=>\Elementor\Controls_Manager::NUMBER,'default'=>6,'min'=>1,'max'=>24]);
  foreach(['featured'=>'Featured projects only','filter'=>'Show category filters and article search','paginate'=>'Pagination','related'=>'Related projects / exclude current entry']as $k=>$label)$this->add_control($k,['label'=>$label,'type'=>\Elementor\Controls_Manager::SWITCHER]);
  $this->end_controls_section();
  $this->start_controls_section('design',['label'=>'Card design','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);
  $this->add_responsive_control('columns',['label'=>'Columns','type'=>\Elementor\Controls_Manager::SELECT,'options'=>['1'=>'1','2'=>'2','3'=>'3'],'default'=>'2','tablet_default'=>'2','mobile_default'=>'1','selectors'=>['{{WRAPPER}} .card-grid'=>'grid-template-columns:repeat({{VALUE}},minmax(0,1fr));']]);
  $this->add_responsive_control('gap',['label'=>'Gap','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>0,'max'=>120]],'selectors'=>['{{WRAPPER}} .card-grid'=>'gap:{{SIZE}}{{UNIT}};']]);
  $this->add_control('stagger',['label'=>'Stagger cards','type'=>\Elementor\Controls_Manager::SWITCHER,'default'=>'yes','selectors'=>['{{WRAPPER}} .editorial-card:nth-child(even)'=>'margin-top:{{VALUE}}px;' ],'selectors_dictionary'=>[''=>'0','yes'=>'90px']]);
  $this->add_group_control(\Elementor\Group_Control_Typography::get_type(),['name'=>'card_title','selector'=>'{{WRAPPER}} .editorial-card h3']);
  $this->end_controls_section();
 }
 protected function render(){$s=$this->get_settings_for_display();foreach(['featured','filter','paginate','related']as $k)$s[$k]=($s[$k]??'')==='yes';echo mbili_listing($s);}
}
class Mbili_Form_Widget extends \Elementor\Widget_Base{
 public function get_name(){return 'mbili_contact';}public function get_title(){return 'Mbili · Inquiry form';}public function get_icon(){return 'eicon-form-horizontal';}public function get_categories(){return ['general'];}
 protected function register_controls(){$this->start_controls_section('content',['label'=>'Contact']);$this->add_control('button_label',['label'=>'Submit label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Send inquiry ↗']);$this->add_control('intro',['label'=>'Form note','type'=>\Elementor\Controls_Manager::TEXTAREA,'default'=>'Tell me what you are building, where you need support, and what a successful collaboration would look like.']);$this->end_controls_section();}
 protected function render(){$s=$this->get_settings_for_display();echo '<p>'.esc_html($s['intro']).'</p>'.mbili_contact_form($s['button_label']);}
}
class Mbili_Media_Widget extends \Elementor\Widget_Base{
 public function get_name(){return 'mbili_media';}public function get_title(){return 'Mbili · Dynamic image';}public function get_icon(){return 'eicon-image';}public function get_categories(){return ['general'];}
 protected function register_controls(){$this->start_controls_section('content',['label'=>'Image']);$this->add_control('source',['label'=>'Source','type'=>\Elementor\Controls_Manager::SELECT,'default'=>'featured','options'=>['featured'=>'Featured image','logo'=>'Client logo']]);$this->add_control('eager',['label'=>'Above-fold image','type'=>\Elementor\Controls_Manager::SWITCHER]);$this->add_control('preview_id',['label'=>'Editor preview post ID','type'=>\Elementor\Controls_Manager::NUMBER]);$this->end_controls_section();$this->start_controls_section('style',['label'=>'Presentation','tab'=>\Elementor\Controls_Manager::TAB_STYLE]);$this->add_responsive_control('image_height',['label'=>'Image height','type'=>\Elementor\Controls_Manager::SLIDER,'range'=>['px'=>['min'=>50,'max'=>1000]],'selectors'=>['{{WRAPPER}} img'=>'height:{{SIZE}}{{UNIT}};object-fit:cover;width:100%;']]);$this->end_controls_section();}
 protected function render(){$s=$this->get_settings_for_display();$id=mbili_context_id();if(\Elementor\Plugin::instance()->editor->is_edit_mode()&&!empty($s['preview_id']))$id=absint($s['preview_id']);$media=$s['source']==='logo'?(mbili_data($id)['logo']??0):get_post_thumbnail_id($id);$html=mbili_media($media,'mbili-hero','',$s['eager']==='yes');if($html)echo $html;elseif(\Elementor\Plugin::instance()->editor->is_edit_mode())echo '<div class="empty-state">Dynamic image — select a preview post ID. Empty images are hidden on the public site.</div>';}
}

class Mbili_Nav_Widget extends \Elementor\Widget_Base{
 public function get_name(){return 'mbili_nav';}public function get_title(){return 'Mbili · Accessible navigation';}public function get_icon(){return 'eicon-nav-menu';}public function get_categories(){return ['general'];}
 protected function register_controls(){
 $this->start_controls_section('content',['label'=>'Navigation']);$this->add_control('menu_label',['label'=>'Mobile toggle label','type'=>\Elementor\Controls_Manager::TEXT,'default'=>'Menu']);$this->end_controls_section();
 }
 protected function render(){ $s=$this->get_settings_for_display();echo '<button class="menu-toggle" aria-expanded="false" aria-controls="primary-menu">'.esc_html($s['menu_label']).' <span aria-hidden="true">＋</span></button><nav id="primary-menu" aria-label="Primary">';wp_nav_menu(['theme_location'=>'primary','container'=>false,'fallback_cb'=>function(){echo '<ul class="menu">';foreach(['work'=>'Work','about'=>'About','writing'=>'Writing','resources'=>'Resources','contact'=>'Contact']as $path=>$label)echo '<li><a href="'.esc_url(home_url('/'.$path.'/')).'">'.esc_html($label).'</a></li>';echo '</ul>';},'depth'=>1]);echo '</nav>'; }
}
