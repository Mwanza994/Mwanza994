<?php
/**
 * Plugin Name: Mbili Platform
 * Description: Portable Case Studies and Resources content models, Elementor widgets, templates, contact handling, and SEO for Mbili Mwanza.
 * Version: 1.0.0
 * Requires at least: 6.6
 * Requires PHP: 8.1
 * License: GPL-2.0-or-later
 * Text Domain: mbili-platform
 */
if (!defined('ABSPATH')) exit;
define('MBILI_PLATFORM_PATH',plugin_dir_path(__FILE__));
define('MBILI_PLATFORM_URL',plugin_dir_url(__FILE__));
require_once __DIR__.'/includes/content.php';
require_once __DIR__.'/includes/render.php';
require_once __DIR__.'/includes/forms-seo.php';
require_once __DIR__.'/includes/setup.php';
add_action('elementor/widgets/register',function($manager){require_once __DIR__.'/includes/widgets.php';$manager->register(new Mbili_Field_Widget());$manager->register(new Mbili_Listing_Widget());$manager->register(new Mbili_Form_Widget());$manager->register(new Mbili_Media_Widget());$manager->register(new Mbili_Nav_Widget());});
register_activation_hook(__FILE__,function(){mbili_register_content();flush_rewrite_rules();});
register_deactivation_hook(__FILE__,function(){flush_rewrite_rules();});
add_filter('the_content',function($content){
 if(is_singular('case_study')&&in_the_loop()&&is_main_query()&&!function_exists('mbili_template')) return $content.mbili_case_body(get_the_ID());
 if(is_singular('mm_resource')&&in_the_loop()&&is_main_query()&&!function_exists('mbili_template')){
 $d=mbili_data(get_the_ID());if(!empty($d['price']))$content.='<p>'.esc_html($d['price']).'</p>';if(!empty($d['affiliate']))$content.='<p>Affiliate disclosure: I may earn a commission if you purchase through this link.</p>';if(!empty($d['destination']))$content.='<p><a href="'.esc_url($d['destination']).'"'.(!empty($d['affiliate'])?' rel="sponsored nofollow"':'').'>Explore resource</a></p>';
 }
 return $content;
},20);
